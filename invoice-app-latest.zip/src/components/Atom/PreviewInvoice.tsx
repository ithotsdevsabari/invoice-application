'use client'
import React,{useEffect, useRef, useState} from 'react';
import html2canvas from 'html2canvas';
import jsPDF from "jspdf";
import Image from 'next/image';
import { useForm } from 'react-hook-form';
import { useParams } from "next/navigation";
import supabase from '@/components/SupaBase';
import { toWords } from 'number-to-words';

const PreviewCreateMode = (props) => {
  const {companydata,clientdata,invoiceItem,completeCompanydeatils} = props;
  console.log(companydata,clientdata,invoiceItem,completeCompanydeatils)

    const { control } = useForm();
    const invoiceRef = useRef();
    
    
    
    const calculateTotals = (data) => {
      let totalAmount = 0;
      let totalDiscountAmount = 0;
    
      data?.forEach(option => {
        const amount = option.rate * option.quantity;
        const discountPrice = (amount * option.discount) / 100;
        const totalDisAmt = amount - discountPrice;   
        const gstAmount = (totalDisAmt * option.gst) / 100;
        const total = gstAmount + totalDisAmt;
    
        totalAmount += total;
        totalDiscountAmount += discountPrice;
      });
    
      return {
        totalAmount,
        totalDiscountAmount,
        totalAmountInWords: toWords(totalAmount),
        totalDiscountAmountInWords: toWords(totalDiscountAmount),
      };
    };
    
    // Check if invoiceDetails is not null and has at least one element
    const totals = invoiceItem && invoiceItem.length > 0 
      ? calculateTotals(invoiceItem) 
      : {
          totalAmount: 0,
          totalDiscountAmount: 0,
          totalAmountInWords: '',
          totalDiscountAmountInWords: '',
        };
    

    
    const downloadAsPdf = (() => {
        alert("ttt")
      const input = invoiceRef.current;
    
      html2canvas(input,{useCORS:true}).then((canvas) => {
        const imgData = canvas.toDataURL('image/png');
    
        const pdf = new jsPDF('p', 'mm', 'a4', true);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const imgWidth = canvas.width;
        const imgHeight = canvas.height;
        const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
        const imgX = (pdfWidth - imgWidth * ratio) / 2;
        const imgY = 30;
        pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
        pdf.save('invoice.pdf')
      });
    });
  

  return (
    

    <section className="py-10 my-14 ">
        <div className='flex justify-center'>

            <button
                onClick={downloadAsPdf}
                className="inline-flex items-center justify-center py-3 px-4 rounded-lg text-sm font-semibold transition-all hover:shadow-lg bg-primary text-white hover:shadow-primary/30 focus:shadow-none focus:outline focus:outline-primary/40 "
            >
                Download
            </button>
            </div>

        <div className="invoice container max-w-[1000px]" ref={invoiceRef}>
         <div className='flex justify-between'>
            <div className="">
                <Image id={'img'} alt="Logo" width={100} height={83} src={completeCompanydeatils[0]?.logo_url} style={{ height: '', width: '200px' }} />
            </div>    
            <div>
                <h1 className='text-3xl text-slate-900 font-normal'>TAX INVOICE</h1>
                </div>  
                </div>                          
                                <div className="flex mb-10">
                                  <div className="xl:w-1/2">
                                      <div className="">
                                          <ul>
                                            <li className="text-gray-900">{completeCompanydeatils[0]?.company_name + completeCompanydeatils[0]?.nick_name}</li>
                                            <li>{completeCompanydeatils[0]?.address} </li>
                                            <li>{completeCompanydeatils[0]?.city}</li>
                                            <li>{completeCompanydeatils[0]?.state}</li>   
                                            <li>{completeCompanydeatils[0]?.country}</li>
                                          </ul>
                                      </div>
                                  </div>
                                  <div className="xl:w-1/2 max-w-[400px] ml-auto">
                                      <div className="text-end">
                                          <div className="">
                                              <ul>
                                                <li><span className='text-gray-900'>PAN NO :</span> {completeCompanydeatils[0]?.pan_number} </li>
                                                <li><span className='text-gray-900'>LUT No :</span> {completeCompanydeatils[0]?.lut_id} </li>
                                                <li><span className='text-gray-900'>GSTIN :</span>{completeCompanydeatils[0]?.gst_number} </li>
                                              </ul>                                              
                                          </div>
                                      </div>                                      
                                  </div>
                                </div>
                                {/* <Link href={"/home/CTA"} >Hiiiiiiiiiiiiiiiiiiiii </Link> */}

                                <div className="flex mb-10">
                                  <div className="xl:w-1/2">
                                      <div className="">
                                        <h3 className='text-gray-900'>Bill To:</h3>
                                          <ul>
                                            <li>{clientdata?.clientCompany}</li>
                                            <li>{clientdata?.clientAddress} </li>
                                            <li>{clientdata?.clientCity}</li>
                                            <li>{clientdata?.clientState}</li>
                                            <li>{clientdata?.clientCountry}</li>
                                            <li><span className='text-gray-900'>GSTIN :</span> {clientdata?.client_gst} </li>
                                          </ul>
                                      </div>
                                  </div>
                                  <div className="xl:w-1/2 max-w-[400px] ml-auto">
                                      <div className="text-end">
                                          <div className="">
                                              <ul>
                                                <li><span className='text-gray-900'>Invoice ID:</span> {completeCompanydeatils[0]?.invoiceId}</li>
                                                <li><span className='text-gray-900'>Invoice Date :</span> {completeCompanydeatils[0]?.invoiceDate} </li>
                                                
                                              </ul>                                              
                                          </div>
                                      </div>                                      
                                  </div>
                                </div>


                                <div className="relative overflow-x-auto sm:rounded-lg mt-10">
                                    <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                                        <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                            <tr>
                                                <th scope="col" className="px-6 py-3">
                                                   Products
                                                </th>
                                                <th scope="col" className="px-6 py-3">
                                                    <div className="flex items-center">
                                                        Rate
                                                    </div>
                                                </th>
                                                <th scope="col" className="px-6 py-3">
                                                    <div className="flex items-center">
                                                        Qty
                                                    </div>
                                                </th>
                                                <th scope="col" className="px-6 py-3">
                                                    <div className="flex items-center">
                                                        Dis
                                                    </div>
                                                </th>
                                                <th scope="col" className="px-6 py-3">
                                                    <div className="flex items-center">
                                                        Gst
                                                    </div>
                                                </th>
                                                {/* <th scope="col" className="px-6 py-3">
                                                    <div className="flex items-center">
                                                        Delete
                                                    </div>
                                                </th> */}
                                                <th scope="col" className="px-6 py-3 text-right">
                                                    <div className="text-right">
                                                        Amount
                                                    </div>
                                                </th>                                                                                        
                                            </tr>
                                        </thead>
                                        
                                        <tbody>
                                            {
                                                 
invoiceItem.map((option,index) =>{ 
  console.log("optio",option)
 let amount = option.rate * option.quantity;
    let discountPrice = (amount / 100) * option.discount
    let totalDisAmt = amount - discountPrice
       let gstAmount = (totalDisAmt / 100) * option.gst
       let totalAmt = gstAmount + totalDisAmt
       console.log("typechecking",option.per_unit_price)
    return(
       <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700" key={index}>
                                                <td scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                                {option.description}
                                                </td>
                                                <td className="px-6 py-4">
                                               {option.rate    +" "+ companydata.currency}
                                                </td>
                                                <td className="px-6 py-4">
                                                
                                                {option.quantity}
                                                </td>
                                                <td className="px-6 py-4">
                                                {`${option.discount}%`}
                                                </td>
                                                <td className="px-6 py-4">
                                                {`${option.gst}%`}
                                                </td>
                                                {/* <td className="px-6 py-4">
                                                <div className="w-6" onClick={() => deleteProducts(index)}> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
                          <path d="M20,29H12a5,5,0,0,1-5-5V12a1,1,0,0,1,2,0V24a3,3,0,0,0,3,3h8a3,3,0,0,0,3-3V12a1,1,0,0,1,2,0V24A5,5,0,0,1,20,29Z"/>
                          <path d="M26,9H6A1,1,0,0,1,6,7H26a1,1,0,0,1,0,2Z"/>
                          <path d="M20,9H12a1,1,0,0,1-1-1V6a3,3,0,0,1,3-3h4a3,3,0,0,1,3,3V8A1,1,0,0,1,20,9ZM13,7h6V6a1,1,0,0,0-1-1H14a1,1,0,0,0-1,1Z"/>
                          <path d="M14,23a1,1,0,0,1-1-1V15a1,1,0,0,1,2,0v7A1,1,0,0,1,14,23Z"/>
                          <path d="M18,23a1,1,0,0,1-1-1V15a1,1,0,0,1,2,0v7A1,1,0,0,1,18,23Z"/>
                        </svg></div>
                                                </td> */}
                                                <td className="px-6 py-4 text-right">
                                               
                                                {  totalAmt.toFixed(2) }
                                                </td>
                                            </tr> 
    )
})
                                            }

                                            
                                          
                                        </tbody>
                                    </table>
                                </div>

                                <div className="ml-auto max-w-[500px]">                              
                                    <div className="relative overflow-x-auto">
                                        <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" aria-hidden="true">
                                            
                                            <thead>
                                                <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                                    <td scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                                    Total
                                                    </td>
                                                    <td className="px-6 py-4 text-right">
                                                    {totals.totalAmount.toFixed(2)+" "+companydata.currency} 
                                                    </td>                                              
                                                </tr>

                                                <tr className="bg-white dark:bg-gray-800 dark:border-gray-700">
                                                    <td scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                                    Amount Payable
                                                    </td>
                                                    <td className="px-6 py-4 text-right">
                                                    {totals.totalAmount.toFixed(2)+" "+companydata.currency} 
                                                    </td>
                                                </tr>
                                                <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                                <td scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                                    Amount in Words
                                                    </td>
                                                   
                                                    <td className="px-6 py-4 text-right">
                                                   Rupees {totals.totalAmountInWords} Only
                                                    </td>
                                                    
                                                </tr>
                                            </thead>
                                        </table>
                                        
                                    </div>

                                </div>


                                <div className="flex my-14">
                                    <div className="w-2/3">
                                        <div className="">
                                            <ul>
                                              <li className="text-gray-900">Bank Details </li>                                              
                                            </ul>
                                        </div>                                      
                                    </div>  

                                    <div className="w-1/3 justify-end">
                                        <div className="text-end ">
                                        <Image id={'img'} alt="Logo" width={100} height={83} src={completeCompanydeatils[0]?.logo_url} style={{ height: '', width: '200px' }} />
                                        </div> 
                                    </div> 
                                </div>

                                <div className="flex pb-12">                                  
                                  <div className="w-2/3">
                                      <div className="">
                                          <div className="">
                                              <ul>
                                                <li className="text-gray-900">Ithots Technology Solutions Pvt Ltd</li>
                                                <li>Cheques payable to Ithots Technology Solutions Pvt. Ltd. or Online Transfer </li>
                                                <li>Ithots Technology Solutions Pvt Ltd </li>
                                                <li>Bank Name: ICICI Bank </li>
                                                <li>Branch : kolathur Branch </li>
                                                <li>Account no : 218405000239 </li>
                                                <li>IFSC Code : ICIC0002184</li>
                                              </ul>                                              
                                          </div>
                                      </div>                                      
                                  </div>
                                  <div className="w-1/3">
                                    <div className="text-center mt-10">
                                    Authorized Signature
                                    </div>
                                  </div>
                                </div>   

                          </div>

                         

    </section>
  )
}

export default PreviewCreateMode

