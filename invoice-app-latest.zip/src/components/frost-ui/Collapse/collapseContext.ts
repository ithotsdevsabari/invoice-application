import { createContext } from 'react'

export const CollapseContext = createContext<any>(false)
