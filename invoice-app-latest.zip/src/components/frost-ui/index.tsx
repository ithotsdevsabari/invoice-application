import FUCollapse from './Collapse'
import SimpleCollapse from './SimpleCollapse'

export { FUCollapse, SimpleCollapse }
