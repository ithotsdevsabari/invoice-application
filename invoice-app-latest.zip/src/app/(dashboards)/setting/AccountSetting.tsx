'use client'
import Link from 'next/link'
import { useForm } from 'react-hook-form'
import { Tab } from '@headlessui/react'
import { FormInput, FormTextArea, FormInputPassword } from '@/components'
import CreateCompany from '@/components/Organism/CreateCompany'
import CreateInvoice from '@/components/Organism/CreateInvoice'
import ViewCompany from '@/components/Organism/ViewCompany';
import supabase from '@/components/SupaBase'
import { useEffect, useState } from 'react'
import CreateClientComp from '@/components/Organism/CreateClient'
import ViewClient from '@/components/Organism/ViewClient'

const AccountSetting = () => {


  const [invoices, setInvoices] = useState([]);
  console.log("invoicelist",invoices)

  useEffect(() => {
    fetchInvoices();
  }, []);

  const fetchInvoices = async () => {
    const { data, error } = await supabase
      .from('invoicelist')
      .select(`*,companylist(company_name)`)
     

    if (error) {
      console.error('Error fetching invoices:', error);
    } else {
      setInvoices(data);
    }
  };

  const deleteInvoice = async (id) => {
    console.log("delete", id);
    try {
      // Start a transaction
      const { data: invoiceItems, error: invoiceItemsError } = await supabase
        .from('invoice_items')
        .delete()
        .eq('invoice_id', id);
  
      if (invoiceItemsError) {
        throw invoiceItemsError;
      }
  
      const { data: invoiceList, error: invoiceListError } = await supabase
        .from('invoicelist')
        .delete()
        .eq('invoice_id', id);

        fetchInvoices();
  
      if (invoiceListError) {
        throw invoiceListError;
      }

  
      console.log('Invoice and related items deleted successfully.');
    } catch (error) {
      console.error('Error deleting data:', error.message);
    }
  };
  

  const { control } = useForm()
  return (
    <div className="bg-slate-100 h-full mt-[77px]  py-3 px-3">
      <section className="relative overflow-hidden">
        <div className="container max-w-[90%] mx-auto px-0">
          <div className="flex">
            <div className="w-full">
              <h3 className="text-xl text-gray-800 mt-2 mb-4 text-center">Company</h3>
            </div>
          </div>
          <div className="flex mt-2">
            <div className="w-full">
              <div className="bg-white rounded">
                <div className="p-6">

                  
                  <div className="grid lg:grid-cols-4 gap-6">
                    <Tab.Group vertical>
                      <div className="col-span-1">
                        <Tab.List
                          as="nav"
                          aria-label="Tabs"
                          className="flex flex-row lg:flex-col gap-2 w-auto lg:w-full bg-slate-100 p-1.5 rounded-md lg:justify-start max-w-[200px]"
                        >
                          <Tab
                            as="button"
                            className={({ selected }) =>
                              `text-start py-2 px-4 rounded transition-all ${selected
                                ? 'bg-white text-primary'
                                : 'bg-transparent'
                              }`
                            }
                            type="button"
                          >
                            Add Company
                          </Tab>

                          <Tab
                            as="button"
                            className={({ selected }) =>
                              `text-start py-2 px-4 rounded transition-all ${selected
                                ? 'bg-white text-primary'
                                : 'bg-transparent'
                              }`
                            }
                            type="button"
                          >
                            List of Company
                          </Tab>

                          <Tab
                            as="button"
                            className={({ selected }) =>
                              `text-start py-2 px-4 rounded transition-all ${selected
                                ? 'bg-white text-primary'
                                : 'bg-transparent'
                              }`
                            }
                            type="button"
                          >
                            Create Invoice
                          </Tab>

                          <Tab
                            as="button"
                            className={({ selected }) =>
                              `text-start py-2 px-4 rounded transition-all ${selected
                                ? 'bg-white text-primary'
                                : 'bg-transparent'
                              }`
                            }
                            type="button"
                          >
                            Create Client
                            
                          </Tab>
                          <Tab
                            as="button"
                            className={({ selected }) =>
                              `text-start py-2 px-4 rounded transition-all ${selected
                                ? 'bg-white text-primary'
                                : 'bg-transparent'
                              }`
                            }
                            type="button"
                          >
                            Client List
                            
                          </Tab>


                          <Tab
                            as="button"
                            className={({ selected }) =>
                              `text-start py-2 px-4 rounded transition-all ${selected
                                ? 'bg-white text-primary'
                                : 'bg-transparent'
                              }`
                            }
                            type="button"
                          >
                          Invoice list  
                          </Tab>

                        </Tab.List>
                      </div>


                      <Tab.Panels className="lg:col-span-3 transition-all px-4 h-full">

                        <Tab.Panel id="account" className="min-h-[650px]">
                        <CreateCompany/>

                        </Tab.Panel>
                        {/* end tab */}
                        
                        <Tab.Panel id="password" className="min-h-[650px]">
                       <ViewCompany/>

                          
                        </Tab.Panel>
                        {/* end tab */}
                        
                        <Tab.Panel id="notifications" className="min-h-[650px]">
                        <CreateInvoice/>

                        </Tab.Panel>


                        <Tab.Panel id="reateClient" className="min-h-[650px]">
                      <CreateClientComp/>

                        </Tab.Panel>

                        <Tab.Panel id="viewClient" className="min-h-[650px]">
                      <ViewClient/>

                        </Tab.Panel>
                        {/* end tab */}

                        <Tab.Panel id="notifications" className="min-h-[650px]">

                        <div className="invoice">
      <h4 className="text-base text-gray-800">Invoice List</h4>                          
      <hr className="my-6" />                                
      <div className="relative overflow-x-auto shadow-md sm:rounded-lg mt-10">
        <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
              <th scope="col" className="px-6 py-3">S.No</th>
              <th scope="col" className="px-6 py-3">Date</th>
              <th scope="col" className="px-6 py-3">Company Name</th>
              <th scope="col" className="px-6 py-3">Invoice No</th>
              <th scope="col" className="px-6 py-3">Amount</th>
              <th scope="col" className="px-6 py-3 text-center">Edit/Delete</th>
              <th scope="col" className="px-6 py-3 text-center">View/Print</th>                                                                                     
            </tr>
          </thead>
          <tbody>
            {invoices.map((invoice, index) => (
              <tr key={invoice.invoice_id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                <td className="px-6 py-4">{index + 1}</td>
                <td className="px-6 py-4">{new Date(invoice.invoice_date).toLocaleDateString()}</td>
                <td className="px-6 py-4">{invoice.companylist.company_name}</td>
                <td className="px-6 py-4">{invoice.invoice_number}</td>
                <td className="px-6 py-4">{parseFloat(invoice.total_amount).toFixed(2)+" "+invoice.invoice_currency}</td>
                <td className="px-6 py-4 text-center">
                  <div className="flex justify-center">                                                  
                    <div className="w-6 mr-3">
                      <Link href={`/edit-invoice/${invoice.id}`}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="feather feather-edit" fill="none" height="24" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" width="24">
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                        </svg>
                      </Link>
                    </div>
                    <div className="w-6" onClick={() => deleteInvoice(invoice.invoice_id)}>
                
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
                          <path d="M20,29H12a5,5,0,0,1-5-5V12a1,1,0,0,1,2,0V24a3,3,0,0,0,3,3h8a3,3,0,0,0,3-3V12a1,1,0,0,1,2,0V24A5,5,0,0,1,20,29Z"/>
                          <path d="M26,9H6A1,1,0,0,1,6,7H26a1,1,0,0,1,0,2Z"/>
                          <path d="M20,9H12a1,1,0,0,1-1-1V6a3,3,0,0,1,3-3h4a3,3,0,0,1,3,3V8A1,1,0,0,1,20,9ZM13,7h6V6a1,1,0,0,0-1-1H14a1,1,0,0,0-1,1Z"/>
                          <path d="M14,23a1,1,0,0,1-1-1V15a1,1,0,0,1,2,0v7A1,1,0,0,1,14,23Z"/>
                          <path d="M18,23a1,1,0,0,1-1-1V15a1,1,0,0,1,2,0v7A1,1,0,0,1,18,23Z"/>
                        </svg>
                  
                    </div>  
                  </div>
                </td>
                <td className="px-6 py-4 text-center">
                  <div className="flex justify-center">  
                    <div className="w-6 mr-3">
                      <Link href={`/preview/${invoice.invoice_id}`}>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                          <defs>
                            <style>{`.a{fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;}`}</style>
                          </defs>
                          <title />
                          <circle className="a" cx="12" cy="12" r="3.5" />
                          <path className="a" d="M23.376,11.672C22.213,10.352,17.562,5.5,12,5.5S1.787,10.352.624,11.672a.5.5,0,0,0,0,.656C1.787,13.648,6.438,18.5,12,18.5s10.213-4.852,11.376-6.172a.5.5,0,0,0,0-.656Z" />
                        </svg>
                      </Link>
                    </div>
                    <div className="w-6">
                      <Link href={`/print-invoice/${invoice.id}`}>
                        <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 0 20 20" width="20">
                          <path d="M3,1V5H0v9h3v5h14v-5h3V5H17V1ZM4,2H16V5H4ZM1,6h2 14 2v7H17V10H3v3H1Zm15,1v1h2V7ZM4,11h12v2 1 4H4v-4-1z m1,1v1h10v-1zm0,2v1h10v-1zm0,2v1h10v-1z" fill="#222222" />
                        </svg>
                      </Link>
                    </div>
                  </div>
                </td> 
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>


                        </Tab.Panel>
                        {/* end tab */}


                      </Tab.Panels>
                    </Tab.Group>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default AccountSetting




