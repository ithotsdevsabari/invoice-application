/** @type {import('next').NextConfig} */
const nextConfig = {
  // basePath: '/prompt_tn',
  // assetPrefix: '/prompt_tn',
  images: {
    unoptimized: true,
  }
}

module.exports = nextConfig
